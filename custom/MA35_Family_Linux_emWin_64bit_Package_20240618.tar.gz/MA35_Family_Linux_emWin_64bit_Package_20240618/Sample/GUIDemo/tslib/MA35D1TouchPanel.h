#ifndef __MA35D1TOUCHPANEL_H__
#define __MA35D1TOUCHPANEL_H__

#include <unistd.h>

void TouchTask(void);

#endif
